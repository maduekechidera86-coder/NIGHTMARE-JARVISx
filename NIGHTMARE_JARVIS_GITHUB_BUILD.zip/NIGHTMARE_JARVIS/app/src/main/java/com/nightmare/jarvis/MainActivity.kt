package com.nightmare.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private val gold = Color.rgb(245, 190, 75)
    private val bg = Color.rgb(8, 10, 18)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition is not available on this device."
        }
    }

    private fun buildScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 48, 24, 24)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "NIGHTMARE JARVIS"
            textSize = 25f; setTextColor(gold); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL ANDROID ASSISTANT"
            textSize = 11f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        val orb = TextView(this).apply {
            text = "✦"; textSize = 76f; setTextColor(gold); gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(25, 28, 40))
                setStroke(3, gold)
            }
        }
        val orbParams = LinearLayout.LayoutParams(190, 190).apply { topMargin = 34; bottomMargin = 24 }
        status = TextView(this).apply {
            text = "SYSTEM ONLINE"; textSize = 14f; setTextColor(gold); gravity = Gravity.CENTER
        }
        transcript = TextView(this).apply {
            text = "Tap the microphone and give me a command."
            textSize = 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(12, 22, 12, 22)
        }
        val mic = Button(this).apply {
            text = "🎙  SPEAK TO JARVIS"
            setTextColor(Color.BLACK); textSize = 15f
            background = GradientDrawable().apply {
                cornerRadius = 28f; setColor(gold)
            }
            setOnClickListener { listen() }
        }
        val help = TextView(this).apply {
            text = "Try: “open YouTube”, “open WhatsApp”, “what time is it?” or “help”."
            textSize = 13f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(10, 22, 10, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(orb, orbParams)
        layout.addView(status)
        layout.addView(transcript, LinearLayout.LayoutParams(-1, 110))
        layout.addView(mic, LinearLayout.LayoutParams(-1, 58))
        layout.addView(help)
        setContentView(layout)
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            respond("Speech recognition is unavailable. Check your Android speech services.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "LISTENING…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "THINKING…" }
            override fun onError(error: Int) { status.text = "READY"; transcript.text = "I didn't catch that. Tap and try again." }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                transcript.text = "You: $words"
                handleCommand(words)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to NIGHTMARE JARVIS")
        }
        recognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String) {
        val q = raw.lowercase(Locale.ROOT).trim()
        when {
            q.contains("hello") || q.contains("hi jarvis") -> respond("Hello. NIGHTMARE JARVIS is online. How may I help?")
            q.contains("time") -> respond("The time is " + java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date()))
            q.contains("date") -> respond("Today is " + java.text.SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(java.util.Date()))
            q.contains("help") -> respond("You can ask me for the time or date, or say open YouTube, WhatsApp, Chrome, Gmail, or Settings.")
            q.contains("weather") -> {
                respond("I can open a weather forecast for you.")
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=weather+today")))
            }
            q.contains("open youtube") -> openApp("com.google.android.youtube", "YouTube")
            q.contains("open whatsapp") -> openApp("com.whatsapp", "WhatsApp")
            q.contains("open chrome") || q.contains("open browser") -> openApp("com.android.chrome", "Chrome")
            q.contains("open gmail") -> openApp("com.google.android.gm", "Gmail")
            q.contains("open settings") -> openApp("com.android.settings", "Settings")
            q.startsWith("search ") -> {
                val term = raw.substringAfter("search ", "")
                respond("Searching the web for $term")
                startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com/search?q=" + android.net.Uri.encode(term))))
            }
            else -> respond("I heard: $raw. I can currently handle app launching, time, date, weather search, and web search.")
        }
    }

    private fun openApp(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            respond("Opening $label.")
            startActivity(launch)
        } else respond("$label is not installed or cannot be opened on this device.")
    }

    private fun respond(message: String) {
        status.text = "SYSTEM ONLINE"
        transcript.text = "JARVIS: $message"
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts.language = Locale.UK
            tts.setSpeechRate(0.92f)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
        else if (requestCode == 41) respond("Microphone permission is needed for voice commands.")
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) { tts.stop(); tts.shutdown() }
        super.onDestroy()
    }
}
