# NIGHTMARE JARVIS — Android starter project

A native Kotlin Android assistant starter with a dark/gold interface, tap-to-speak speech recognition, spoken replies using the device's UK English TTS voice when available, basic commands, app launching, web search, and weather search.

## Current capabilities
- Tap **SPEAK TO JARVIS** and speak a command.
- Opens YouTube, WhatsApp, Chrome, Gmail, and Android Settings when installed.
- Reads the current time and date aloud.
- Opens a web weather search.
- Uses Android's speech-recognition service and Text-to-Speech engine.

## Important limitations
- This starter does **not** listen continuously for a wake word or clap. Android restricts background microphone use; always-on listening needs a carefully designed foreground service and visible notification.
- It is not yet connected to a cloud AI model. Unknown questions receive a basic fallback response.
- A British voice is selected only if the device has a compatible UK English TTS voice installed.
- Weather opens a search page rather than reading live weather data.
- Microphone permission is requested at runtime.

## Build an APK
1. Install Android Studio on a computer.
2. Open this `NIGHTMARE_JARVIS` folder in Android Studio.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

The project uses Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. This environment did not have the Android SDK or Gradle installed, so an APK could not be compiled here. The source project is provided intact for building in Android Studio.


## Build free using GitHub Actions (phone-friendly)
1. Extract this ZIP on your phone with a ZIP file manager.
2. Create a **public** repository on GitHub (GitHub Actions has free minutes for public repositories).
3. Upload the project contents, including the hidden `.github/workflows/android.yml` file, to the repository's `main` branch. Make sure `settings.gradle.kts`, `build.gradle.kts`, and the `app` folder are at the repository root.
4. Open the repository's **Actions** tab and select **Build NIGHTMARE JARVIS APK**. If prompted, enable workflows and tap **Run workflow**.
5. When the run completes, open it and download the `NIGHTMARE-JARVIS-debug-apk` artifact. Extract the artifact ZIP to get `app-debug.apk`.
6. Install the APK. Android may ask you to allow installation from your browser or file manager.

Keep API keys and private credentials out of a public repository. This starter currently needs no API key.
